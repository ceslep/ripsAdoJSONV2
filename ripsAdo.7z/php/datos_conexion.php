<?php
	        ini_set('error_reporting', E_ALL);		
		/*
			$host="localhost";
            $user="qovgnzuu_root";
		  	$pass="Qpzm894035*";
		  	$database="qovgnzuu_instituto"; 
		*/	
			$host="localhost";
            $user="root";
		  	$pass="894035";
		  	$database="ado"; 
			$database_imagenes="ado_fotos"; 
	
?>